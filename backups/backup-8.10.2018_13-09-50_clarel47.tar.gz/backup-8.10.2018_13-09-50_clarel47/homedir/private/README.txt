Access to this directory is available only to you. 
The directory cannot be accessed via any web or system services, so you can 
store any private information here.
